<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateTeams extends \Google\AdsApi\AdManager\v201802\TeamAction
{

    
    public function __construct()
    {
    
    }

}
