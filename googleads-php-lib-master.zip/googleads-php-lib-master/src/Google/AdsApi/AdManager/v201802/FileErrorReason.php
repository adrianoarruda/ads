<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class FileErrorReason
{
    const MISSING_CONTENTS = 'MISSING_CONTENTS';
    const SIZE_TOO_LARGE = 'SIZE_TOO_LARGE';
    const UNKNOWN = 'UNKNOWN';


}
