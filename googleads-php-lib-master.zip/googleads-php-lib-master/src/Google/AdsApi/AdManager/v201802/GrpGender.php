<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class GrpGender
{
    const UNKNOWN = 'UNKNOWN';
    const GENDER_UNKNOWN = 'GENDER_UNKNOWN';
    const GENDER_FEMALE = 'GENDER_FEMALE';
    const GENDER_MALE = 'GENDER_MALE';


}
