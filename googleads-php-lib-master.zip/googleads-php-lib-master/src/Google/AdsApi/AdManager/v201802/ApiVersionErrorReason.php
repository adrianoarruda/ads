<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ApiVersionErrorReason
{
    const UPDATE_TO_NEWER_VERSION = 'UPDATE_TO_NEWER_VERSION';
    const UNKNOWN = 'UNKNOWN';


}
