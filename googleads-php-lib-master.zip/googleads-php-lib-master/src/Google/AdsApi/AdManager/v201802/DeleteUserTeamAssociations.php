<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeleteUserTeamAssociations extends \Google\AdsApi\AdManager\v201802\UserTeamAssociationAction
{

    
    public function __construct()
    {
    
    }

}
