<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AudienceSegmentType
{
    const FIRST_PARTY = 'FIRST_PARTY';
    const SHARED = 'SHARED';
    const THIRD_PARTY = 'THIRD_PARTY';
    const UNKNOWN = 'UNKNOWN';


}
