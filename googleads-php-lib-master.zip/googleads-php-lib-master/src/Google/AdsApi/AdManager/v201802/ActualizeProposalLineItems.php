<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActualizeProposalLineItems extends \Google\AdsApi\AdManager\v201802\ProposalLineItemAction
{

    
    public function __construct()
    {
    
    }

}
