<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeviceCategory extends \Google\AdsApi\AdManager\v201802\Technology
{

    /**
     * @param int $id
     * @param string $name
     */
    public function __construct($id = null, $name = null)
    {
      parent::__construct($id, $name);
    }

}
