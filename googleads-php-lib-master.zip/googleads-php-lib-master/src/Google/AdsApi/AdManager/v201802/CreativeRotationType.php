<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CreativeRotationType
{
    const EVEN = 'EVEN';
    const OPTIMIZED = 'OPTIMIZED';
    const MANUAL = 'MANUAL';
    const SEQUENTIAL = 'SEQUENTIAL';


}
