<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class FeatureErrorReason
{
    const MISSING_FEATURE = 'MISSING_FEATURE';
    const UNKNOWN = 'UNKNOWN';


}
