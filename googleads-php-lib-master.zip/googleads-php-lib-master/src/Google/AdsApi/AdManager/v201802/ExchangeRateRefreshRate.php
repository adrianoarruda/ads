<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ExchangeRateRefreshRate
{
    const FIXED = 'FIXED';
    const DAILY = 'DAILY';
    const MONTHLY = 'MONTHLY';
    const UNKNOWN = 'UNKNOWN';


}
