<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeactivateRateCards extends \Google\AdsApi\AdManager\v201802\RateCardAction
{

    
    public function __construct()
    {
    
    }

}
