<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class GrpProvider
{
    const UNKNOWN = 'UNKNOWN';
    const NIELSEN = 'NIELSEN';
    const GOOGLE = 'GOOGLE';


}
