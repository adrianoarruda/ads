<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ImageDensity
{
    const ONE_TO_ONE = 'ONE_TO_ONE';
    const THREE_TO_TWO = 'THREE_TO_TWO';
    const TWO_TO_ONE = 'TWO_TO_ONE';
    const UNKNOWN = 'UNKNOWN';


}
