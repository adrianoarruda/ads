<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class GoalType
{
    const NONE = 'NONE';
    const LIFETIME = 'LIFETIME';
    const DAILY = 'DAILY';
    const UNKNOWN = 'UNKNOWN';


}
