<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ActivateContentBundles extends \Google\AdsApi\AdManager\v201802\ContentBundleAction
{

    
    public function __construct()
    {
    
    }

}
