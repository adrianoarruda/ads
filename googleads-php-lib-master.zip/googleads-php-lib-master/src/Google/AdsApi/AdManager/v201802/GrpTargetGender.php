<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class GrpTargetGender
{
    const UNKNOWN = 'UNKNOWN';
    const MALE = 'MALE';
    const FEMALE = 'FEMALE';
    const BOTH = 'BOTH';


}
