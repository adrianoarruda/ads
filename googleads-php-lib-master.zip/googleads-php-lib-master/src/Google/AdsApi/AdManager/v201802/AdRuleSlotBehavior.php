<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdRuleSlotBehavior
{
    const ALWAYS_SHOW = 'ALWAYS_SHOW';
    const NEVER_SHOW = 'NEVER_SHOW';
    const DEFER = 'DEFER';
    const UNKNOWN = 'UNKNOWN';


}
