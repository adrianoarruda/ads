<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdExchangeEnvironment
{
    const DISPLAY = 'DISPLAY';
    const VIDEO = 'VIDEO';
    const GAMES = 'GAMES';
    const MOBILE = 'MOBILE';
    const UNKNOWN = 'UNKNOWN';


}
