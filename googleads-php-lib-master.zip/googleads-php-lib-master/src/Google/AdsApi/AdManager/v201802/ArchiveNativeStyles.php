<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ArchiveNativeStyles extends \Google\AdsApi\AdManager\v201802\NativeStyleAction
{

    
    public function __construct()
    {
    
    }

}
