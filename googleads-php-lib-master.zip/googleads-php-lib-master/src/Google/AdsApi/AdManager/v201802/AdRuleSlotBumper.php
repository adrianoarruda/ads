<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdRuleSlotBumper
{
    const NONE = 'NONE';
    const BEFORE = 'BEFORE';
    const AFTER = 'AFTER';
    const BEFORE_AND_AFTER = 'BEFORE_AND_AFTER';
    const UNKNOWN = 'UNKNOWN';


}
