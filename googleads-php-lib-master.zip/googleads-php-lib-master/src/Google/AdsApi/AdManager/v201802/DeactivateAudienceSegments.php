<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeactivateAudienceSegments extends \Google\AdsApi\AdManager\v201802\AudienceSegmentAction
{

    
    public function __construct()
    {
    
    }

}
