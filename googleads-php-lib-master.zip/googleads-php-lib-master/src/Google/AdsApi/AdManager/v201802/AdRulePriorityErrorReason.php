<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdRulePriorityErrorReason
{
    const DUPLICATE_PRIORITY = 'DUPLICATE_PRIORITY';
    const PRIORITIES_NOT_SEQUENTIAL = 'PRIORITIES_NOT_SEQUENTIAL';
    const UNKNOWN = 'UNKNOWN';


}
