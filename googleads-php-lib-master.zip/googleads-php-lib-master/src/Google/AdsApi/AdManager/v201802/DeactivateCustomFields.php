<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class DeactivateCustomFields extends \Google\AdsApi\AdManager\v201802\CustomFieldAction
{

    
    public function __construct()
    {
    
    }

}
