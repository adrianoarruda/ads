<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CustomFieldVisibility
{
    const API_ONLY = 'API_ONLY';
    const READ_ONLY = 'READ_ONLY';
    const FULL = 'FULL';


}
