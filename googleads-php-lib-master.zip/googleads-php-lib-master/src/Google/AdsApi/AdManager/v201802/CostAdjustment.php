<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CostAdjustment
{
    const NONE = 'NONE';
    const MAKE_GOOD = 'MAKE_GOOD';
    const BARTER = 'BARTER';
    const ADDED_VALUE = 'ADDED_VALUE';
    const UNKNOWN = 'UNKNOWN';


}
