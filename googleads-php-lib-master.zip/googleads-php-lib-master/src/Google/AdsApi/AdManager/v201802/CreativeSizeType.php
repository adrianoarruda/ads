<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CreativeSizeType
{
    const PIXEL = 'PIXEL';
    const ASPECT_RATIO = 'ASPECT_RATIO';
    const INTERSTITIAL = 'INTERSTITIAL';
    const NATIVE = 'NATIVE';


}
