<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdSenseSettingsFontFamily
{
    const DEFAULT_VALUE = 'DEFAULT';
    const ARIAL = 'ARIAL';
    const TAHOMA = 'TAHOMA';
    const GEORGIA = 'GEORGIA';
    const TIMES = 'TIMES';
    const VERDANA = 'VERDANA';


}
