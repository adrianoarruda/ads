<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdRuleTargetingErrorReason
{
    const VIDEO_POSITION_TARGETING_NOT_ALLOWED = 'VIDEO_POSITION_TARGETING_NOT_ALLOWED';
    const UNKNOWN = 'UNKNOWN';


}
