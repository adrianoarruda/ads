<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class BillFrom
{
    const DEFAULT_VALUE = 'DEFAULT';
    const DFP = 'DFP';
    const THIRD_PARTY = 'THIRD_PARTY';
    const MANUAL = 'MANUAL';
    const UNKNOWN = 'UNKNOWN';


}
