<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class BaseRateActionErrorReason
{
    const PRODUCT_BASE_RATE_EXISTS = 'PRODUCT_BASE_RATE_EXISTS';
    const UNKNOWN = 'UNKNOWN';


}
