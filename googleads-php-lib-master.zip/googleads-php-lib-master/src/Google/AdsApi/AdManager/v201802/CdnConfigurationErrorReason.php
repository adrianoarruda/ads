<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class CdnConfigurationErrorReason
{
    const URL_SHOULD_NOT_CONTAIN_SCHEME = 'URL_SHOULD_NOT_CONTAIN_SCHEME';
    const INVALID_DELIVERY_LOCATION_NAMES = 'INVALID_DELIVERY_LOCATION_NAMES';
    const UNKNOWN = 'UNKNOWN';


}
