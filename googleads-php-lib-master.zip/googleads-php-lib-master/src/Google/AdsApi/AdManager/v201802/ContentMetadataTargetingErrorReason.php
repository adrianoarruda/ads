<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class ContentMetadataTargetingErrorReason
{
    const VALUES_DO_NOT_BELONG_TO_A_HIERARCHY = 'VALUES_DO_NOT_BELONG_TO_A_HIERARCHY';
    const UNKNOWN = 'UNKNOWN';


}
