<?php

namespace Google\AdsApi\AdManager\v201802;


/**
 * This file was generated from WSDL. DO NOT EDIT.
 */
class AdSenseSettingsBorderStyle
{
    const DEFAULT_VALUE = 'DEFAULT';
    const NOT_ROUNDED = 'NOT_ROUNDED';
    const SLIGHTLY_ROUNDED = 'SLIGHTLY_ROUNDED';
    const VERY_ROUNDED = 'VERY_ROUNDED';


}
